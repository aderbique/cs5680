function edgeHist = CalEdgeHist(im, bin)
%CALEDGEHIST Summary of this function goes here
%   Detailed explanation goes here

edgeHist = im;

end

