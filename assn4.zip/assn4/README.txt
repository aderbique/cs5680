Austin Derbique
A01967241
Due: 10/24/2017

Dear Grader,

This readme file is to help guide direction into grading. 

Problem 1: 
 part 1: Complete, Uses file called gaussian_low_pass.m
 part 2: Complete, Uses file called butterworth_high_pass.m
 
Problem 2:
  part 1: Complete, Uses file called turbulizeIm.m
  part 2: Complete, Uses file called Wiener1.m
  
Problem 3: Complete, This part is done in Main.m

Problem 4: Uses file called remove_cosine_noise.m
  part 1: Complete
  part 2: Complete
  part 3: Complete - Console outputs the indices of 4 largest pairs of distinct magnitudes
  part 4: Complete - Displays inversed Image, however it did not come back properly. I had trouble getting the ifft2 function to return real number.
  part 5: Complete, I took the four largest distinct values of the magnitude because these corespond to the sinusoidal wave max - giving an explanation as to what the period was and how much it should be shifted by.
  
Problem 5: This part is done in Main.m
  part 1: Complete
  part 2: Attemped, Not entirely working

Problem 6: This part is done in Main.m
  part 1: Complete
  part 2: Complete
  part 3: Complete
  part 4: Complete
  part 5: Attempted, not entirely working
  part 6: Attempted, not entirely working
  part 6: Attempted, not entirely working
  part 8: Complete
  part 9: Complete
  